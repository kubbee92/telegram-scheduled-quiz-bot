"""TelegramClient behaviour with the network mocked (no database needed)."""
import os
import sys

import pytest
import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from telegram_api import TelegramClient, TelegramError  # noqa: E402

TOKEN = "123456:SECRET-TOKEN"


class Resp:
    def __init__(self, status, body=None, bad_json=False):
        self.status_code, self._body, self._bad = status, body, bad_json

    def json(self):
        if self._bad:
            raise ValueError("no json")
        return self._body


def client(monkeypatch, outcome):
    def fake_post(url, **kw):
        assert TOKEN in url
        kw_sent.update(kw)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome
    kw_sent = {}
    monkeypatch.setattr(requests, "post", fake_post)
    c = TelegramClient(TOKEN)
    c.sent = kw_sent
    return c


QUIZ = {"question": "Q?", "options": ["a", "b"], "correct": 1, "explanation": "why"}


def test_quiz_payload_is_anonymous_single_answer_quiz_in_topic(monkeypatch):
    c = client(monkeypatch, Resp(200, {"ok": True, "result": {"message_id": 1}}))
    c.send_quiz(-100, 55, QUIZ)
    p = c.sent["json"]
    assert p["type"] == "quiz" and p["is_anonymous"] is True and p["allows_multiple_answers"] is False
    assert p["correct_option_id"] == 1 and p["message_thread_id"] == 55 and p["explanation"] == "why"
    c.send_quiz(-100, 0, {**QUIZ, "explanation": ""})
    assert "message_thread_id" not in c.sent["json"] and "explanation" not in c.sent["json"]


def test_telegram_refusal_is_definitive_and_token_free(monkeypatch):
    c = client(monkeypatch, Resp(400, {"ok": False, "error_code": 400, "description": "Bad Request: chat not found"}))
    with pytest.raises(TelegramError) as e:
        c.send_quiz(-100, 1, QUIZ)
    assert e.value.definitive and e.value.code == 400


@pytest.mark.parametrize("outcome", [
    Resp(502, bad_json=True),
    Resp(500, {"ok": False, "error_code": 500, "description": "Internal"}),
    requests.ReadTimeout(f"read timeout on https://api.telegram.org/bot{TOKEN}/sendPoll"),
    requests.ConnectionError(f"reset https://api.telegram.org/bot{TOKEN}/sendPoll"),
])
def test_unknown_outcomes_are_not_definitive_and_token_is_redacted(monkeypatch, outcome):
    c = client(monkeypatch, outcome)
    with pytest.raises(TelegramError) as e:
        c.send_quiz(-100, 1, QUIZ)
    assert not e.value.definitive
    assert TOKEN not in str(e.value)


def test_connect_timeout_is_definitive(monkeypatch):
    c = client(monkeypatch, requests.ConnectTimeout(f"x {TOKEN}"))
    with pytest.raises(TelegramError) as e:
        c.send_message(1, "hi")
    assert e.value.definitive and TOKEN not in str(e.value)


def test_missing_token_fails_cleanly():
    with pytest.raises(TelegramError, match="BOT_TOKEN"):
        TelegramClient("")._call("getMe")
