"""Tests run against a real Postgres (set TEST_DATABASE_URL) with a fake Telegram.

    TEST_DATABASE_URL=postgresql://postgres@127.0.0.1:5544/quiztest pytest -q
WARNING: the tests wipe the tables in that database.
"""
import io
import os
import random
import sys
from datetime import datetime, timedelta

import openpyxl
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as app_module  # noqa: E402
import config  # noqa: E402
import db  # noqa: E402
import excel_io  # noqa: E402
import handlers  # noqa: E402
import scheduler  # noqa: E402
from telegram_api import TelegramError  # noqa: E402

TEST_URL = os.environ.get("TEST_DATABASE_URL")
pytestmark = pytest.mark.skipif(not TEST_URL, reason="TEST_DATABASE_URL not set")

ADMIN = 5839558908
GROUP = -1001234567890
MONDAY = "2026-11-02"  # a Monday -> logic


def at(h, m=0, day=MONDAY):
    y, mo, d = map(int, day.split("-"))
    return datetime(y, mo, d, h, m, tzinfo=config.ADDIS_TZ)


class FakeTG:
    def __init__(self):
        self.quizzes, self.messages, self.documents = [], [], []
        self.clock = None
        self.files = {}
        self.quiz_error = None

    def send_quiz(self, chat_id, thread_id, q):
        if self.quiz_error:
            raise self.quiz_error
        self.quizzes.append((chat_id, thread_id, q["question"], q["correct"], q["explanation"], self.clock))

    def send_message(self, chat_id, text, thread_id=None):
        self.messages.append((chat_id, text, thread_id))

    def send_document(self, chat_id, filename, content, caption=None):
        self.documents.append((chat_id, filename, content))

    def download_file(self, file_id, max_bytes):
        return self.files[file_id]

    def texts_to(self, chat_id):
        return [t for c, t, _ in self.messages if c == chat_id]


@pytest.fixture(autouse=True)
def clean_db(monkeypatch):
    monkeypatch.setattr(config, "DATABASE_URL", TEST_URL)
    monkeypatch.setattr(config, "ADMIN_IDS", {ADMIN})
    db.ensure_schema(force=True)
    with db.tx() as cur:
        cur.execute("TRUNCATE alert_log, schedule, questions, topics RESTART IDENTITY CASCADE")
    yield


def make_rows(subject, n, prefix="Q"):
    return [
        excel_io.Row(i, subject, f"{prefix}{i}", ["a", "b", "c"], 1, "because",
                     excel_io._hash(subject, f"{prefix}{i}"))
        for i in range(1, n + 1)
    ]


def set_all_topics():
    for i, s in enumerate(config.SUBJECTS):
        db.set_topic(s, GROUP, 100 + i)


def workbook_bytes(rows, header=("subject", "question", "A", "B", "C", "D", "correct", "explanation")):
    wb = openpyxl.Workbook()
    ws = wb.active
    if header:
        ws.append(list(header))
    for r in rows:
        ws.append(list(r))
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------- Excel parsing
def test_parse_valid_and_invalid_rows():
    data = workbook_bytes([
        ("Math", "2+2?", "3", "4", "5", "6", "B", "basic"),
        ("physics", "Unit of force?", "N", "J", None, None, "a", ""),
        ("art", "x?", "1", "2", None, None, "A", ""),                    # unknown subject
        ("math", "Bad correct", "1", "2", None, None, "D", ""),          # D is empty
        ("math", "Gap", "1", "2", None, "4", "A", ""),                   # C empty, D filled
        ("math", "Long expl", "1", "2", None, None, "A", "x" * 201),
        ("math", "Q" * 301, "1", "2", None, None, "A", ""),
        ("math", "One option", "1", None, None, None, "A", ""),
        ("math", "Same", "yes", "YES", None, None, "A", ""),
        ("math", "2+2?", "3", "4", "5", "6", "B", "dup in file"),        # duplicate
        ("math", "[SAMPLE] ignore me", "1", "2", None, None, "A", ""),
        ("math", "Numeric opts", 5, 6.0, 7, None, 2, ""),                # 5.0 -> "5", correct=2 -> B
    ])
    res = excel_io.parse_workbook(data)
    assert [r.subject for r in res.rows] == ["math", "physics", "math"]
    assert res.rows[1].correct == 0
    assert res.rows[2].options == ["5", "6", "7"] and res.rows[2].correct == 1
    assert res.samples == 1
    assert res.duplicates == [11]
    assert sorted(n for n, _ in res.errors) == [4, 5, 6, 7, 8, 9, 10]


def test_parse_header_variants_and_errors():
    data = workbook_bytes([("math", "Q", "1", "2", "B")],
                          header=("Subject", "Question text", "Option A", "Option B", "Answer"))
    assert len(excel_io.parse_workbook(data).rows) == 1
    with pytest.raises(excel_io.ExcelFormatError):
        excel_io.parse_workbook(b"not an excel file")
    with pytest.raises(excel_io.ExcelFormatError):
        excel_io.parse_workbook(workbook_bytes([("a", "b")], header=("foo", "bar")))
    with pytest.raises(excel_io.ExcelFormatError, match="Missing column"):
        excel_io.parse_workbook(workbook_bytes([("math", "Q")], header=("subject", "question")))


def test_template_roundtrip_has_only_samples():
    res = excel_io.parse_workbook(excel_io.build_template())
    assert res.rows == [] and res.errors == [] and res.samples == 7


# ---------------------------------------------------------------- slot planning
def test_plan_slots_always_in_window_with_gap():
    rng = random.Random(1)
    day = datetime(2026, 11, 2).date()
    start, end = at(18, 30), at(21, 0)
    for _ in range(2000):
        t1, t2 = scheduler.plan_slots(day, at(0, 5), rng)
        assert start <= t1 < t2 <= end
        assert t2 - t1 >= config.MIN_GAP


def test_plan_slots_when_started_late_does_not_go_in_the_past():
    rng = random.Random(2)
    now = at(20, 50)
    t1, t2 = scheduler.plan_slots(datetime(2026, 11, 2).date(), now, rng)
    assert t1 > now and t2 - t1 >= config.MIN_GAP


# ---------------------------------------------------------------- the tick
def tick(tg, h, m=0, day=MONDAY, rng=None):
    tg.clock = at(h, m, day)
    return scheduler.run_tick(tg.clock, tg, rng or random.Random(0))


def plan_day(tg, t1, t2, day=MONDAY):
    """First tick of the day (creates the schedule), then pin the two post times."""
    tick(tg, 0, 5, day)
    d = at(0, 0, day).date()
    with db.tx() as cur:
        cur.execute("UPDATE schedule SET planned_at = %s WHERE day = %s AND slot = 1",
                    (at(*t1, day), d))
        cur.execute("UPDATE schedule SET planned_at = %s WHERE day = %s AND slot = 2",
                    (at(*t2, day), d))


def cron_evening(tg, day=MONDAY, start=(18, 25), end=(21, 35)):
    """Ping every 5 minutes like the external cron service does."""
    t, stop = at(*start, day), at(*end, day)
    while t <= stop:
        tick(tg, t.hour, t.minute, day)
        t += timedelta(minutes=5)


def slot_statuses(day=MONDAY):
    return [x["status"] for x in db.today_slots(at(0, 0, day).date())]


def test_random_schedule_posts_two_quizzes_inside_the_window():
    for seed in range(30):
        tg = FakeTG()
        db.insert_questions(make_rows("logic", 2, prefix=f"s{seed}-"), ADMIN)
        set_all_topics()
        tick(tg, 0, 5, rng=random.Random(seed))
        t = at(18, 25)
        while t <= at(21, 35):
            tg.clock = t
            scheduler.run_tick(t, tg, random.Random(seed))
            t += timedelta(minutes=5)
        assert len(tg.quizzes) == 2, seed
        t1, t2 = (q[5] for q in tg.quizzes)
        assert at(18, 30) <= t1 < t2 <= at(21, 5)         # window + one 5-minute ping
        assert t2 - t1 >= config.MIN_GAP
        with db.tx() as cur:
            cur.execute("TRUNCATE alert_log, schedule, questions RESTART IDENTITY CASCADE")


def test_two_quizzes_posted_in_upload_order_with_low_queue_alert():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 3), ADMIN)
    plan_day(tg, (19, 0), (19, 40))
    assert tick(tg, 12)["sent"] == 0 and tg.quizzes == []
    assert tick(tg, 19, 5)["sent"] == 1
    assert tick(tg, 19, 45)["sent"] == 1
    assert [q[2] for q in tg.quizzes] == ["Q1", "Q2"]
    assert all(q[0] == GROUP and q[1] == 100 for q in tg.quizzes)  # the logic topic
    assert tg.quizzes[0][3] == 1 and tg.quizzes[0][4] == "because"
    # 1 question left (< 2 needed next week) -> exactly one warning
    assert len([t for t in tg.texts_to(ADMIN) if "Only 1 Logic" in t]) == 1
    tick(tg, 19, 50)
    tick(tg, 20, 0)
    assert len(tg.quizzes) == 2                                    # never re-sent


def test_each_weekday_uses_its_subject():
    tg = FakeTG()
    set_all_topics()
    for s in config.SUBJECTS:
        db.insert_questions(make_rows(s, 2, prefix=s + "-"), ADMIN)
    days = ["2026-11-02", "2026-11-03", "2026-11-04", "2026-11-05",
            "2026-11-06", "2026-11-07", "2026-11-08"]
    for day in days:
        tick(tg, 0, 5, day)
        cron_evening(tg, day)
    posted = [q[2].split("-")[0] for q in tg.quizzes]
    assert posted == [s for s in config.SUBJECTS for _ in range(2)]
    assert len(tg.quizzes) == 14


def test_empty_queue_alerts_once_then_sends_after_upload():
    tg = FakeTG()
    set_all_topics()
    plan_day(tg, (18, 45), (19, 30))
    tick(tg, 19, 0)
    tick(tg, 19, 35)
    tick(tg, 19, 36)
    assert len([t for t in tg.texts_to(ADMIN) if "queue is empty" in t]) == 1
    assert tg.quizzes == []

    db.insert_questions(make_rows("logic", 2), ADMIN)
    assert tick(tg, 19, 40)["sent"] == 2                           # inside the 2h grace
    assert [q[2] for q in tg.quizzes] == ["Q1", "Q2"]


def test_missing_topic_alerts_and_keeps_question():
    tg = FakeTG()
    db.insert_questions(make_rows("logic", 2), ADMIN)
    plan_day(tg, (18, 45), (19, 30))
    tick(tg, 19, 35)
    assert tg.quizzes == []
    assert any("/settopic logic" in t for t in tg.texts_to(ADMIN))
    assert db.pending_count("logic") == 2
    db.set_topic("logic", GROUP, 7)
    assert tick(tg, 19, 40)["sent"] == 2
    assert all(q[1] == 7 for q in tg.quizzes)


def test_late_wakeup_skips_quizzes_and_alerts():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 2), ADMIN)
    assert tick(tg, 23, 30)["sent"] == 0
    assert tg.quizzes == [] and set(slot_statuses()) == {"missed"}
    assert any("skipped" in t for t in tg.texts_to(ADMIN))
    assert db.pending_count("logic") == 2


def test_slot_past_grace_is_marked_missed_and_admin_told():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 2), ADMIN)
    plan_day(tg, (18, 45), (19, 30))                                # no ping between 18:45 and 22:00
    tick(tg, 22, 0)
    assert set(slot_statuses()) == {"missed"} and tg.quizzes == []
    assert len([t for t in tg.texts_to(ADMIN) if "not posted in time" in t]) == 1


def test_config_error_retries_then_fails_without_burning_question():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 2), ADMIN)
    plan_day(tg, (19, 0), (19, 40))
    tg.quiz_error = TelegramError("400: Bad Request: chat not found", code=400, definitive=True)
    for m in (5, 10, 15):
        tick(tg, 19, m)
    assert slot_statuses() == ["failed", "planned"]
    for m in (45, 50, 55):
        tick(tg, 19, m)
    assert slot_statuses() == ["failed", "failed"]
    assert db.pending_count("logic") == 2                           # nothing burned
    assert len([t for t in tg.texts_to(ADMIN) if "couldn't post" in t]) == 1
    tg.quiz_error = None                                            # fixed -> next week works
    plan_day(tg, (19, 0), (19, 40), day="2026-11-09")
    assert tick(tg, 19, 45, day="2026-11-09")["sent"] == 2


def test_bad_question_content_is_rejected_and_skipped():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 3), ADMIN)
    plan_day(tg, (19, 0), (19, 40))
    tg.quiz_error = TelegramError("400: Bad Request: option text is invalid", code=400, definitive=True)
    for m in (5, 10, 15):
        tick(tg, 19, m)
    assert db.queue_counts()["logic"].get("rejected") == 1
    tg.quiz_error = None
    assert tick(tg, 19, 45)["sent"] == 1
    assert [q[2] for q in tg.quizzes] == ["Q2"]                     # Q1 skipped, queue not blocked


def test_ambiguous_send_is_never_retried_and_admin_is_told():
    tg = FakeTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 4), ADMIN)
    plan_day(tg, (19, 0), (19, 40))
    tg.quiz_error = TelegramError("network error: read timeout", definitive=False)
    assert tick(tg, 19, 5)["unconfirmed"] == 1
    assert slot_statuses() == ["sending", "planned"]
    tg.quiz_error = None
    tick(tg, 19, 20)                                                # >10 min later
    assert slot_statuses() == ["unconfirmed", "planned"] and tg.quizzes == []
    assert any("never got confirmation" in t for t in tg.texts_to(ADMIN))
    assert db.queue_counts()["logic"]["sent"] == 1                  # treated as posted
    tick(tg, 19, 45)
    assert [q[2] for q in tg.quizzes] == ["Q2"]                     # Q1 never re-sent


# ---------------------------------------------------------------- handlers
def upd(text=None, uid=ADMIN, chat_id=ADMIN, chat_type="private", thread=None, document=None):
    m = {"from": {"id": uid}, "chat": {"id": chat_id, "type": chat_type}}
    if text is not None:
        m["text"] = text
    if document:
        m["document"] = document
    if thread:
        m["message_thread_id"] = thread
        m["is_topic_message"] = True
    return {"message": m}


def test_non_admin_is_ignored_in_group_and_refused_in_private():
    tg = FakeTG()
    handlers.handle_update(upd("/settopic math", uid=42, chat_id=GROUP, chat_type="supergroup", thread=9), tg)
    assert tg.messages == [] and db.get_topic("math") is None
    handlers.handle_update(upd("/queue", uid=42, chat_id=42), tg)
    assert "private" in tg.messages[0][1]


def test_settopic_inside_topic_and_general():
    tg = FakeTG()
    handlers.handle_update(upd("/settopic@MyQuizBot Math", chat_id=GROUP, chat_type="supergroup", thread=55), tg)
    t = db.get_topic("math")
    assert (t["chat_id"], t["thread_id"]) == (GROUP, 55)
    assert tg.messages[-1][2] == 55  # confirmation posted inside that topic
    handlers.handle_update(upd("/settopic history", chat_id=GROUP, chat_type="supergroup"), tg)
    assert db.get_topic("history")["thread_id"] == 0
    handlers.handle_update(upd("/settopic nonsense", chat_id=GROUP, chat_type="supergroup"), tg)
    assert "Usage" in tg.messages[-1][1]


def test_upload_flow_end_to_end():
    tg = FakeTG()
    tg.files["f1"] = workbook_bytes([
        ("math", "Q1", "1", "2", None, None, "A", "e"),
        ("math", "Q2", "1", "2", None, None, "B", "e"),
        ("english", "Q3", "x", "y", None, None, "Z", "e"),       # bad correct
    ])
    doc = {"file_id": "f1", "file_name": "new.xlsx", "file_size": 1000}
    handlers.handle_update(upd(document=doc), tg)
    reply = tg.messages[-1][1]
    assert "Added 2 questions" in reply and "Math: 2" in reply and "Row 4" in reply
    assert db.pending_count("math") == 2

    handlers.handle_update(upd(document=doc), tg)                 # same file again
    assert "Skipped 2 duplicates" in tg.messages[-1][1]
    assert db.pending_count("math") == 2

    handlers.handle_update(upd(document={"file_id": "x", "file_name": "q.csv", "file_size": 1}), tg)
    assert ".xlsx" in tg.messages[-1][1]
    tg.files["bad"] = b"garbage"
    handlers.handle_update(upd(document={"file_id": "bad", "file_name": "q.xlsx", "file_size": 7}), tg)
    assert "couldn't open" in tg.messages[-1][1]


def test_queue_template_topics_and_help_commands():
    tg = FakeTG()
    db.insert_questions(make_rows("math", 5), ADMIN)
    handlers.handle_update(upd("/queue"), tg)
    assert "Math (Fri): 5 left" in tg.messages[-1][1] and "⚠️ Logic" in tg.messages[-1][1]
    handlers.handle_update(upd("/template"), tg)
    assert tg.documents[-1][1] == "questions_template.xlsx"
    handlers.handle_update(upd("/topics"), tg)
    assert "not set" in tg.messages[-1][1]
    handlers.handle_update(upd("/start"), tg)
    assert "Mon=logic" in tg.messages[-1][1] and "Sun=history" in tg.messages[-1][1]


# ---------------------------------------------------------------- web layer
@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(config, "CRON_SECRET", "cron-secret")
    monkeypatch.setattr(config, "WEBHOOK_SECRET", "hook-secret")
    fake = FakeTG()
    monkeypatch.setattr(scheduler, "TelegramClient", lambda: fake)
    monkeypatch.setattr(handlers, "TelegramClient", lambda: fake)
    c = app_module.app.test_client()
    c.fake = fake
    return c


def test_tick_requires_key(client):
    assert client.get("/tick").status_code == 403
    assert client.get("/tick?key=wrong").status_code == 403
    r = client.get("/tick?key=cron-secret")
    assert r.status_code == 200 and "sent" in r.get_json()
    assert client.post("/tick", headers={"X-Cron-Key": "cron-secret"}).status_code == 200


def test_tick_unconfigured_secret_is_refused(client, monkeypatch):
    monkeypatch.setattr(config, "CRON_SECRET", "")
    assert client.get("/tick?key=").status_code == 503


def test_webhook_checks_secret_and_dispatches(client):
    body = upd("/queue")
    assert client.post("/webhook", json=body).status_code == 403
    assert client.post("/webhook", json=body, headers={"X-Telegram-Bot-Api-Secret-Token": "nope"}).status_code == 403
    r = client.post("/webhook", json=body, headers={"X-Telegram-Bot-Api-Secret-Token": "hook-secret"})
    assert r.status_code == 200 and "Questions left" in client.fake.messages[-1][1]


def test_webhook_swallows_internal_errors(client, monkeypatch):
    def boom(update, tg=None):
        raise RuntimeError("db down")
    monkeypatch.setattr(handlers, "handle_update", boom)
    r = client.post("/webhook", json=upd("/queue"), headers={"X-Telegram-Bot-Api-Secret-Token": "hook-secret"})
    assert r.status_code == 200


def test_overlapping_ticks_never_double_post():
    import threading
    import time

    class SlowTG(FakeTG):
        def send_quiz(self, chat_id, thread_id, q):
            time.sleep(0.3)
            super().send_quiz(chat_id, thread_id, q)

    tg = SlowTG()
    set_all_topics()
    db.insert_questions(make_rows("logic", 6), ADMIN)
    plan_day(tg, (19, 0), (19, 0, ))                 # both slots due at the same moment
    with db.tx() as cur:
        cur.execute("UPDATE schedule SET planned_at = %s WHERE slot = 2", (at(19, 1),))
    now = at(19, 10)
    threads = [threading.Thread(target=lambda: scheduler.run_tick(now, tg)) for _ in range(6)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert sorted(q[2] for q in tg.quizzes) == ["Q1", "Q2"]     # exactly two, no repeats
    assert slot_statuses() == ["sent", "sent"]
